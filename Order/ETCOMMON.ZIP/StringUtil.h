#ifndef _STRINGUTIL_H_INCLUDED_
#define _STRINGUTIL_H_INCLUDED_
#include "CommonDefs.h"
#include <stdlib.h>
#include <string>
#include <iostream>
#include <stdlib.h>
#include <string>

#include "atlbase.h"
#include "atlstr.h"
#include "comutil.h"


#pragma once
using namespace std;


#ifdef _UNICODE
#define TCHARToUTF8 WideToUTF8
#define UTF8ToTCHAR UTF8ToWide
#define TCHARToWide
#define WideToTCHAR
#define TCHARToMB WideToMB 
#define MBToTCHAR MBToWide
#else
#define TCHARToUTF8 ANSIToUTF8
#define UTF8ToTCHAR UTF8ToANSI
#define TCHARToWide MBToWide
#define WideToTCHAR WideToMB
#define TCHARToMB
#define MBToTCHAR
#endif

class CStringUtil
{
public:
	CStringUtil(void);
	virtual ~CStringUtil(void);

	void Split(const tstring& str, std::vector<tstring>& out, TCHAR sep, bool includeEmpty);
	tstring GetWord(const tstring& str, unsigned index, bool getRest = false);

	inline bool Compare(const tstring& one, const tstring& two, bool caseSensitive)
	{
		return caseSensitive ? (one == two) : (_tcsicmp(one.c_str(), two.c_str()) == 0);
	};
};

#endif//_STRINGUTIL_H_INCLUDED_