#pragma once
#include <strsafe.h>
#include "ClientDetails.h"
#include "HttpClient.h"

class COMMON_API COAuthHelper
{
public:
	COAuthHelper(void);
	virtual ~COAuthHelper(void);

	//this function will genereate OAuth params, singunature and Authoration header and also submit HTTPs request.
	string OauthSignAndSubmitRequest(CClientDetails &ObjClientDetails,string Url, HttpMethodConstants httpMethod = GETMethod, string postParameter = "",string strVerifier = "",bool bRequstToken = false) throw (...);
	int GetHttpResponceCode(void);
	HTTPParameters ParseQueryString( const string& url ) ;
	string BuildQueryString( const HTTPParameters &parameters ) ;
private:
	int m_HttpResponceCode;
	string UrlGetQuery( const string& url ) ;
	string HMACSHA1( const string& keyBytes, const string& data ) ;
	string Base64String( const string& hash );
	string char2hex( char dec );
	string urlencode(const string &c);
	string UrlEncode( const string& url ); 

	string OAuthBuildHeader( const HTTPParameters &parameters ) ;
	string OAuthCreateNonce();
	string OAuthCreateTimestamp() ;
	string OAuthCreateSignature( const string& signatureBase, const string& consumerSecret, const string& requestTokenSecret/*, bool bEncode = false */) ;
	string OAuthConcatenateRequestElements( HttpMethodConstants httpMethod, string url, const string& parameters );
	string OAuthNormalizeRequestParameters( const HTTPParameters& requestParameters ) ;
	string OAuthNormalizeUrl( const string& url ) ;
	HTTPParameters BuildSignedOAuthParameters(CClientDetails & ObjClientDetails, const HTTPParameters& getParameters, const string& url,  HttpMethodConstants httpMethod, string postParameters,string pin, bool bRequstToken = false) throw (...);
};

