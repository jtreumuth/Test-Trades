#pragma once

#ifndef _CLIENTDETAILS_H_INCLUDED_
#define _CLIENTDETAILS_H_INCLUDED_

using namespace std;

#include "CommonDefs.h"

#ifdef COMMON_LIBRARY_EXPORT // inside DLL
#   define COMMON_API   __declspec(dllexport)
#else // outside DLL
#   define COMMON_API   __declspec(dllimport)
#endif  // COMMON_LIBRARY_EXPORT

class COMMON_API CClientDetails
{
public:
	CClientDetails();
	CClientDetails(string strConsumerKey,string strConsumerSecret,Environment environment);
	virtual ~CClientDetails ();

	Environment GetEnv();
	void SetEnv(Environment env);

	string GetConsumerKey();
	void SetConsumerKey(string consumerKey);

	string GetConsumerSecret();
	void SetConsumerSecret(string consumerSecret);
	
	string GetToken();
	void SetToken(string token);

	string GetTokenSecret();
	void SetTokenSecret(string tokenSecret);

private :
	Environment m_environment;
	string m_strConsumerKey;
	string m_strConsumerSecret;
	string m_strToken;
	string m_strTokenSecret;
	string m_strCallback;
};
#endif//_CLIENTDETAILS_H_INCLUDED_