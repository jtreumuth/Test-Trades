#pragma once
class CLogger
{
public:
	CLogger(void);
	virtual ~CLogger(void);
};

