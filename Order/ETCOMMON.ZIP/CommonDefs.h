#pragma once

#ifndef _COMMONDEFS_H_INCLUDED_
#define _COMMONDEFS_H_INCLUDED_

#include "StdAfx.h"
#include "ErrorCode.h"

using namespace std;

class CExceptionSDK
{
public:
	CExceptionSDK():m_nHTTPErrorCode(0),m_nErrorCode(0),m_strErrorMsg(_T("")){}
	int m_nHTTPErrorCode;
	int m_nErrorCode;
	CString m_strErrorMsg;
};

typedef enum 
{
	SANDBOX	= 0,
	LIVE	= 1
}Environment;

typedef enum  
{
	GETMethod		= 0,
	POSTMethod		= 1,
	DELETEMethod	= 2
}HttpMethodConstants;

typedef std::map<string, string> HTTPParameters;

#endif//_COMMONDEFS_H_INCLUDED_