#pragma once
#include "CommonDefs.h"

class  CHttpClient
{
public :
	CHttpClient();
	virtual ~CHttpClient();

	string HttpRequestSubmit(const string& strUrl, const string& oauthParameters,HttpMethodConstants HttpMethod,string  &postParameters,int &nHttpResponceCode) throw (...);
	string CHttpClient::GetHttpResponceString();
	int GetHttpResponceCode();

private:
	BOOL ParseHttpResponse(HINTERNET hHttp) throw (...);
	string GetHttpMethodFromEnum(HttpMethodConstants httpMethodEnum);
	void InitHttp();

	HINTERNET m_hINet;
	string m_strHttpResponce;
	int m_iResponceCode;
};

